Thanks for downloading this template!

Template Name: Yummy
Template URL: https://bootstrapmade.com/yummy-bootstrap-restaurant-website-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
